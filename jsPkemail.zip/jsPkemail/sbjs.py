#𝐀𝐧𝐭𝐚𝐫𝐞𝐬[𝐃𝐨𝐥𝐥𝐲] 𝙋.𝙆_𝘽𝙊𝙏𝙎 update 23-11-2020
#Thank For Aki DEVAN ,Ben,Igo,Dzul DK
#Thank for °™ᴀʟɪᴘ•GRIND KILLER
#Supported by Babysha,dira,onay,padel,firman
#𝐁𝐓𝐑 𝐟𝐚𝐦𝐢𝐥𝐲[BONE TO REBORN] Ibal v2™ & friend
#𝐌𝐨𝐫𝐩𝐡𝐢𝐧𝐞𝐁𝐨𝐭𝐬
#Thank for 𝐄𝐋𝐅𝐎𝐗 
#THANKS for Dragon Killer Supported lip dll
#all family famz kebotan
#SelfBot Suport Bypass/Js
#ini Buat kawan" yg udah Pc Admin mintain via email
import pantek
from pantek import *
from akad.ttypes import *
from datetime import datetime
import pytz, pafy, null, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, codecs, tweepy, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, urllib, urllib.parse, urllib3, string, tempfile, shutil, unicodedata
from humanfriendly import format_timespan, format_size, format_number, format_length
import html5lib
import requests,json,urllib3
from random import randint
from bs4 import BeautifulSoup
from googletrans import Translator
import youtube_dl
from time import sleep
from zalgo_text import zalgo
from threading import Thread,Event
import wikipedia as wiki
requests.packages.urllib3.disable_warnings()
from tmp.Instagram import InstagramScraper
from Naked.toolshed.shell import execute_js 
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest


botStart = time.time()
msg_dict = {}
msg_dict1 = {}
#=============Login Email=============
pkbotjs = LINE("email@gmail.com","pw")
pkbotjs.log("Auth Token : " + str(pkbotjs.authToken))
pkbotjs.log("Timeline Token : " + str(pkbotjs.tl.channelAccessToken))

oepoll = OEPoll(pkbotjs)
pkbotjsProfile = pkbotjs.getProfile()
pkbotjsSettings = pkbotjs.getSettings()
mid = pkbotjs.profile.mid
mid = pkbotjs.getProfile().mid
print ("LOGIN READY : " + mid)
print ("PROSES")
print ("︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ ")
print ("======1%\n=======50%\n=========100%")
print (" ᴛʜᴀɴᴋs ᴛᴏ ᴀʟʟᴀʜ sᴡᴛ ")
print (" ᴛʜᴀɴᴋs ᴛᴏ ᴘʏ³ ")
print (" ᴋᴇᴇᴘ sᴛᴀʏ ᴀɴᴅ ʀᴜʟʟᴇs ")
print ("\n\
= = = = = = = = = = = =        =====               === \n\
= = = = = = = = = = = = =      =====            === \n\
=======          ====== =      =====         === \n\
=======           ====== =     =====      ===\n\
=======           =======      =====    === \n\
=======           ======       ===== ===\n\
=================              ===== ===\n\
================               =====     ===\n\
=======                        =====      ===  \n\
=======                        =====         ===\n\
=======                        =====           ===\n\
=======                        =====             === \n")
print("LOGIN SUKSES")
print ("SELFBOT SIAP DI GUNAKAN\n own=𝐀𝐧𝐭𝐚𝐫𝐞𝐬[𝐃𝐨𝐥𝐥𝐲] 𝙋.𝙆_𝘽𝙊𝙏𝙎 \n\n")

#===kasih mid admin,mid yg mau bawa bot ke group=====
creator = ["u3a4cc9a5d0da4077d7dc6cd4f405517c"] #kalau bisa jgn di ganti wkwkwk
owner = ["mid"]
admin = ["mid","mid"] #bisa bnyak mid buat admin supaya bisa bawa bot ke room
staff = ["mid"]
Bots = ["mid"]

Team = creator + owner + admin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

blacklist = []
targets = []
_dn = []
warmode = []
welcome = []
msg_dict = {}
msg_dict1 = {}

settings = {"Picture":False,"group":{},"groupPicture":False,"changePicture":False,"autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0","Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5","Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0","Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0","Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}
wait = {
    "limit": 1,
    "creator":{},
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "autoAdd":True,
    'autoJoin':True,
    'autoLeave':False,
    "protectqr":False,
    "protectinvite":False,
    "protectjoin":False,
    "protectkick":False,
    "protectantijs":True,
    "protectcancel":False,
    "backup":True,
    "Pantek":True,
    "selfbot":True,
    "Response":"︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ \nStay siap tempur",
    "Respontag":"jangan tag gw anjing",
    "welcome":"Kam anak anjing",
    "comment":"ᴀᴜᴛᴏʟɪᴋᴇ ʙʏ: \n\n\n\n︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ",
    "message":"kenapa lu add bangsat",
}
read = {"readPoint":{},"readMember":{},"readTime":{},"ROM":{},}
cctv = {"cyduk":{},"point":{},"sidermem":{}}
#=================================================================================#
helpMessage ="""          ☆𝙋.𝙆 𝙎𝙀𝙇𝙁𝘽𝙊𝙏𝙎☆
▪cekbot
▪Pk/pkbot [Cek Team 𝙋.𝙆°𝘽𝙊𝙏𝙎]
▪mid
▪refresh
▪restart
▪runtime
▪Respon
▪out
▪sp
▪myfriend
▪glist
▪listbot
▪listadmin
▪name: [ganti nama]
▪upbot [ganti foto]
▪Cban
▪Banlist
        ●ᴊꜱ/ʙʏᴘᴀꜱꜱ ᴏʀ ᴋɪᴄᴋ●
▪ .bypass [number]
▪ js dari dalam
▪ tebas [depan kasih titik]
▪ Kick @
▪ Vkick [nama]
▪ out [number]
      🇮🇩𝙋.𝙆 𝙏𝙀𝘼𝙈𝘽𝙊𝙏𝙎°2020🇮🇩"""
#=================================================================================#
mulai = time.time()
tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
def logError(text):
    pkbotjs.log("[ Pk__killer ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("Pkkiller.txt","a") as error:
        error.write("\n[{}] {}".format(str(time), text))

def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.001)        
            page = page[end_content:]
    return items

def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def backupProfile():
    profile = pkbotjs.getContact(mid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = pkbotjs.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)

def sendSticker(to, version, packageId, stickerId):
    contentMetadata = {
        'STKVER': version,
        'STKPKGID': packageId,
        'STKID': stickerId
    }
    pkbotjs.sendMessage(to, '', contentMetadata, 7)

def backupData():
    try:
        backup1 = Setmain
        f = codecs.open('setting.json','w','utf-8')
        json.dump(backup1, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup2 = settings
        f = codecs.open('settings.json','w','utf-8')
        json.dump(backup2, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup3 = wait
        f = codecs.open('wait.json','w','utf-8')
        json.dump(backup3, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup4 = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup4, f, sort_keys=True, indent=4, ensure_ascii=False)        
        return True
    except Exception as error:
        logError(error)
        return False

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d ʜᴀʀɪ %02d ᴊᴀᴍ %02d ᴍᴇɴɪᴛ %02d ᴅᴇᴛɪᴋ' % (days, hours, mins, secs)

def famzmention(to, mids=[]):
    parsed_len = len(mids)//20+1
    result = '╭──「ᴍᴇɴᴛɪᴏɴ_ᴍᴇᴍʙᴇʀs」\n'
    mention = 'ABSEN SETAN\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '│ %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '╰──「︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ 」'
        if result:
            if result.endswith('\n'): result = result[:-1]
            pkbotjs.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''

def sendMention39(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "  ︻╦̵̵͇̿̿̿̿╤─PANTEK ᵏⁱˡˡᵉʳ "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    pkbotjs.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 11:
            if wait["protectqr"] == True:
                try:
                    if pkbotjs.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            X = pkbotjs.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                            pkbotjs.updateGroup(X)
                            wait["blacklist"][op.param2] = True
                except:
                    pass

            if op.param2 in wait["blacklist"]:
                try:
                    if pkbotjs.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            X = pkbotjs.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                            pkbotjs.updateGroup(X)
                            wait["blacklist"][op.param2] = True
                except:
                	pass
                
        if op.type == 13:
            if wait["protectinvite"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                pkbotjs.cancelGroupInvitation(op.param1,[_mid])
                                pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass

        if op.type == 19:
            if wait["protectkick"] == True:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        pkbotjs.rejectGroupInvitation(op.param1)
                    else:
                        pkbotjs.acceptGroupInvitation(op.param1)

        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                pkbotjs.cancelGroupInvitation(op.param1,[_mid])
                                pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass

        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                pkbotjs.cancelGroupInvitation(op.param1,[_mid])
                                pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass

        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                try:
                    pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                except:
                    pass

        if op.type == 17:
            if wait["protectjoin"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                    except Exception as e:
                        print(e)

        if op.type == 32:
            if wait["protectcancel"] == True:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
#-----------------------------------------------------------------------------------------------------------------------
        if op.type == 19 or op.type == 32:
            if op.param3 in creator:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                        pkbotjs.findAndAddContactsByMid(op.param3)
                        pkbotjs.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass

            if op.param3 in owner:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                        pkbotjs.findAndAddContactsByMid(op.param3)
                        pkbotjs.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass

            if op.param3 in admin:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                        pkbotjs.findAndAddContactsByMid(op.param3)
                        pkbotjs.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass

            if op.param3 in staff:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                        pkbotjs.findAndAddContactsByMid(op.param3)
                        pkbotjs.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass

            if op.param3 in Bots:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["protectjoin"] = True
                    wait["protectinvite"] = True
                    wait["protectqr"] = True
                    try:
                        pkbotjs.kickoutFromGroup(op.param1,[op.param2])
                        pkbotjs.findAndAddContactsByMid(op.param3)
                        pkbotjs.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        pass
#-------------------------------------------------------------------------------------------------------------------------------
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        pkbotjs.sendMessage(op.param1, wait["message"])

        if op.type == 55:
            try:
                if op.param1 in Setmain["PkreadPoint"]:
                   if op.param2 in Setmain["PkreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["PkreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
               try:
                   pkbotjs.kickoutFromGroup(op.param1,[op.param2])
               except:
                   pass
                   
        if op.type ==  26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if wait ["Pantek"] == True:
            	if msg._from not in Team:
                    if msg.text in ["!bubar",".cipok","!cupok","js","!js",".sikat","!sikat","sikat","Bubar",".bubar","Cleanse","!cleanse",".cleanse","Kickall","!kickall",".kickall","mayhem","Ratakan","bubarkan","Nuke","nuke",".nuke","Bypass","bypass",".bypass","hancurkan","!malam","winebot",".malam"]:
                        pkbotjs.kickoutFromGroup(receiver,[sender])

        if op.type == 25 or op.type == 26:
            print ("[25/26] OPMSG")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = pkbotjs.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            pkbotjs.sendMessage(msg.to, "✓Berhasil Menambahkan Gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["Pkfoto"]:
                            path = pkbotjs.downloadObjectMsg(msg_id)
                            del Setmain["Pkfoto"][mid]
                            pkbotjs.updateProfilePicture(path)
                            pkbotjs.sendMessage(msg.to, "✓ᴘʀᴏғɪʟᴇ ᴘʜᴏᴛᴏ\nsᴜᴄᴄᴇssғᴜʟʟʏ ᴄʜᴀɴɢᴇᴅ")
                     
               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        pkbotjs.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               pkbotjs.sendMessage(msg.to,helpMessage)

                        if cmd == "bot on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                pkbotjs.sendMessage(msg.to, "Selfbot on \n Siap perang")
                                
                        elif cmd == "bot off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                pkbotjs.sendMessage(msg.to, "Selfbot off")
                                
                        if cmd == "cekbot":
                            if msg._from in admin:
                                try:pkbotjs.kickoutFromGroup(to, [mid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has1 == "OK":sil1 = "👉👌Sangek"
                                else:sil1 = "😓Lemas"
                                pkbotjs.sendMessage(to, "> status {}".format(sil1))
                               
                        elif cmd == "me" or text.lower() == '.me':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               contact = pkbotjs.getContact(sender)
                               pkbotjs.sendMessage(msg.to, None,contentMetadata={'mid': sender}, contentType=13)

                        elif text.lower() == "mid":
                               pkbotjs.sendMessage(msg.to, msg._from)

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = pkbotjs.getContact(key1)
                               pkbotjs.sendMessage(msg.to, "▪ ɴᴀᴍᴀ : "+str(mi.displayName)+"\n▪ ᴍɪᴅ : " +key1+"\n▪ sᴛᴀᴛᴜs ᴍsɢ : "+str(mi.statusMessage))
                               pkbotjs.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(pkbotjs.getContact(key1)):
                                   pkbotjs.sendVideoWithURL(msg.to, 'https://profile.line-scdn.net/'+str(mi.picturePath)+'/vp.small')
                               else:
                                   pkbotjs.sendImageWithURL(msg.to, 'https://profile.line-scdn.net/'+str(mi.picturePath))
                              
                        elif cmd  == "midbots":
                          if msg._from in admin:
                              pkbotjs.sendMessage(msg.to, mid)                              
 
                        elif cmd == "about":
                          if wait["selfbot"] == True:
                               pkbotjs.sendMessage(msg.to, "       𝙋.𝙆 𝙎𝙀𝙇𝙁𝘽𝙊𝙏𝙎 \n▪Selfbot Js\n▪Team=𝙋.𝙆 𝙏𝙀𝘼𝙈𝘽𝙊𝙏𝙎\n▪Creator=𝐀𝐧𝐭𝐚𝐫𝐞𝐬[𝐃𝐨𝐥𝐥𝐲]\n\n       Supported by:\n•Aki Devan\n•Ben [𝐃𝐚𝐢𝐥𝐲 𝐔𝐬𝐞]\n•IGO [BALWEL]\n•𝐁𝐓𝐑 𝐟𝐚𝐦𝐢𝐥𝐲 Ibal & Friend\n•°™ᴀʟɪᴘ•GRIND KILLER\n•☆𝕱𝖆𝖒𝖟 𝖐𝖊𝖇𝖔𝖙𝖆𝖓☆\n\n         𝙋.𝙆_𝘽𝙊𝙏𝙎  2020\n")                                            
                               
                        elif cmd == "pk" or text.lower() == 'pkbot':
                          if wait["selfbot"] == True:                            
                               pkbotjs.sendMessage(msg.to,"𝐰𝐞 𝐚𝐫𝐞 𝐡𝐞𝐫𝐞, 𝐚𝐧𝐝 𝐚𝐥𝐰𝐚𝐲𝐬 𝐰𝐢𝐥𝐥 𝐛𝐞 𝐡𝐞𝐫𝐞")
                                                    
                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in mid:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)                                
                                md = "│╔══🔹️Status SelfbotS🔹️\n"                                
                                if wait["sticker"] == True: md+="│╠══[  ON  ] sᴛɪᴄᴋᴇʀ✔️\n"
                                else: md+="│╠══[ OFF ] sᴛɪᴄᴋᴇʀ❌\n"
                                if wait["contact"] == True: md+="│╠══[  ON  ] ᴄᴏɴᴛᴀᴄᴛ✔️\n"
                                else: md+="│╠══[ OFF ] ᴄᴏɴᴛᴀᴄᴛ❌\n"
                                if wait["detectMention"] == True: md+="│╠══[  ON  ] ʀᴇsᴘᴏɴ✔️\n"
                                else: md+="│╠══[ OFF ] ʀᴇsᴘᴏɴ❌\n"
                                if wait["autoJoin"] == True: md+="│╠══[  ON  ] ᴀᴜᴛᴏᴊᴏɪɴ✔️\n"
                                else: md+="│╠══[ OFF ] ᴀᴜᴛᴏᴊᴏɪɴ❌\n"
                                if settings["autoJoinTicket"] == True: md+="│╠══[  ON  ] ᴊᴏɪɴᴛɪᴄᴋᴇᴛ✔️\n"
                                else: md+="│╠══[ OFF ] ᴊᴏɪɴᴛɪᴄᴋᴇᴛ❌\n"
                                if wait["autoBlock"] == True: md+="│╠══[  ON  ] autoblock ✔️\n"
                                else: md+="│╠══[ OFF ] autoblock ❌\n"
                                if settings["unsendMessage"] == True: md+="│╠══[  ON  ] ᴜɴsᴇɴᴅ✔️\n"
                                else: md+="│╠══[ OFF ] ᴜɴsᴇɴᴅ❌\n"
                                if wait["autoAdd"] == True: md+="│╠══[  ON  ] ᴀᴜᴛᴏᴀᴅᴅ✔️\n"
                                else: md+="│╠══[ OFF ] ᴀᴜᴛᴏᴀᴅᴅ❌\n"
                                if msg.to in welcome: md+="│╠══[  ON  ] ᴡᴇʟᴄᴏᴍᴇ✔️\n"
                                else: md+="│╠══[ OFF ] ᴡᴇʟᴄᴏᴍᴇ❌\n"
                                if wait["autoLeave"] == True: md+="│╠══[  ON  ] ᴀᴜᴛᴏʟᴇᴀᴠᴇ✔️\n"
                                else: md+="│╠══[ OFF ] ᴀᴜᴛᴏʟᴇᴀᴠᴇ❌\n"                               
                                if msg.to in protectqr: md+="│╠══[  ON  ] ᴘʀᴏᴛᴇᴄᴛǫʀ✔️\n"
                                else: md+="│╠══[ OFF ] ᴘʀᴏᴛᴇᴄᴛǫʀ❌\n"
                                if msg.to in protectjoin: md+="│╠══[  ON  ] ᴘʀᴏᴛᴇᴄᴛᴊᴏɪɴ✔️\n"
                                else: md+="│╠══[ OFF ] ᴘʀᴏᴛᴇᴄᴛᴊᴏɪɴ❌\n"
                                if msg.to in protectkick: md+="│╠══[  ON  ] ᴘʀᴏᴛᴇᴄᴛᴋɪᴄᴋ✔️\n"
                                else: md+="│╠══[ OFF ] ᴘʀᴏᴛᴇᴄᴛᴋɪᴄᴋ❌\n"
                                if msg.to in protectinvite: md+="│╠══[  ON  ] ᴘʀᴏᴛᴇᴄᴛɪɴᴠɪᴛᴇ✔️\n"
                                else: md+="│╠══[ OFF ] ᴘʀᴏᴛᴇᴄᴛɪɴᴠɪᴛᴇ❌\n"
                                if msg.to in protectantijs: md+="│╠══[  ON  ] ᴊs✔️\n"
                                else: md+="│╠══[ OFF ] ᴊs❌\n"                                
                                if msg.to in protectcancel: md+="│╠══[  ON  ] ᴘʀᴏᴛᴇᴄᴛᴄᴀɴᴄᴇʟ✔️\n"
                                else: md+="│╠══[ OFF ] ᴘʀᴏᴛᴇᴄᴛᴄᴀɴᴄᴇʟ❌\n"
                                pkbotjs.sendMessage(msg.to, md+"\n│ᴛᴀɴɢɢᴀʟ : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n│ᴊᴀᴍ  "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
                                
                        elif text.lower() == "refresh":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   pkbotjs.removeAllMessages(op.param2)
                                   pkbotjs.sendMessage(msg.to, "Done Nyet")
                               except:
                                   pass

#==============Js& bypass====================                         
                        elif text.lower() == "js":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                client = LINE(token,appName=appF)
                                x = client.getGroup(msg.to)
                                nami = [contact.mid for contact in x.members]
                                abort = False
                                targetk = []
                                cms = 'kick.js gid={} token={} app={}'.format(to,token,appF)
                                for a in nami:
                                    if a not in admin and a not in Bots:
                                        targetk.append(a)
                                if msg._from not in admin:
                                    for m in nami:
                                        if m in admin and a not in Bots:
                                            abort = True
                                for y in targetk:
                                    cms += ' uid={}'.format(y)
                                if abort:
                                    for m in admin:
                                        pkbotjs.sendMessage(to,'Cannot destroy {} ,there are my admin'.format(x.name))
                                        pkbotjs.sendText(m,'User trying to destroy your room.')
                                        pkbotjs.sendContact(m,msg._from)
                                else:
                                    pkbotjs.sendMessage(to,'Sabar anjing limit gw ntar {}'.format(x.name))
                                    success = execute_js(cms)
                                    if success:
                                        pkbotjs.sendMessage(to,'Nah Aman ')
                                    else:
                                        pkbotjs.sendMessage(to,'error')
                                
                        elif text.lower() == ".tebas":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                x = pkbotjs.getGroup(msg.to)
                                anu = x.id
                                if x.invitee == None:nama = []
                                else:nama = [contact.mid for contact in x.invitee]
                                targets = []
                                for a in nama:
                                    if a not in admin and a not in Bots:
                                        targets.append(a)
                                nami = [contact.mid for contact in x.members]
                                targetk = []
                                cms = 'baypass.js gid={} token={} app={}'.format(anu,token,appF)
                                for a in nami:
                                    if a not in admin and a not in Bots:
                                        targetk.append(a)
                                for y in targets:
                                    cms += ' uid={}'.format(y)
                                for y in targetk:
                                    cms += ' uik={}'.format(y)
                                print(cms)
                                success = execute_js(cms)
#====Bypass Remote==========
                        if text.startswith('.bypass '):
                            if msg._from in admin:
                                text = msg.text.split()
                                number = text[1]
                                if number.isdigit():
                                    groups = pkbotjs.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)]
                                        try:
                                            x = pkbotjs.getGroup(groupid)
                                            anu = x.id
                                            if x.invitee == None:nama = []
                                            else:nama = [contact.mid for contact in x.invitee]
                                            targets = []
                                            for a in nama:
                                                if a not in admin and a not in Bots:
                                                    targets.append(a)
                                            nami = [contact.mid for contact in x.members]
                                            targetk = []
                                            cms = 'baypass.js gid={} token={} app={}'.format(anu,token,appF)
                                            for a in nami:
                                                if a not in admin and a not in Bots:
                                                    targetk.append(a)
                                            for y in targets:
                                                cms += ' uid={}'.format(y)
                                            for y in targetk:
                                                cms += ' uik={}'.format(y)
                                            print(cms)
                                            success = execute_js(cms)
                                            if success:
                                                pkbotjs.sendMessage(msg.to,"Succes Baypass \n " + str(x.name))
                                            else:
                                                pkbotjs.sendMessage(msg.to,"Limit Bose")
                                        except:
                                            pass
    
                        elif cmd == "restart":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               pkbotjs.sendMessage(msg.to, "Done Nyet")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "▪ʙᴏᴛ ʀᴜɴ :\n" +waktu(eltime)
                               pkbotjs.sendMessage(msg.to,bot)

                        elif cmd == "absen" or cmd == "respon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["protectjoin"] = False
                                wait["protectinvite"] = False
                                wait["protectqr"] = False
                                pkbotjs.sendMessage(msg.to, wait["Response"])
                                     
                        elif cmd == "out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = pkbotjs.getGroup(msg.to)                                
                                pkbotjs.leaveGroup(msg.to)
#============================================
                        if cmd.startswith('out '):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                text = msg.text.split()
                                number = text[1]
                                if number.isdigit():
                                    groups = pkbotjs.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)]
                                        group = pkbotjs.getGroup(groupid)
                                        target = sender
                                        try:
                                            pkbotjs.getGroup(groupid)
                                            pkbotjs.sendMessage(groupid,"Cabut Dulu bray\nPenting Chat owner")
                                            pkbotjs.leaveGroup(groupid)
                                            pkbotjs.sendMessage(msg.to,"Succes Leave to\n " + str(group.name))
                                        except:
                                            pkbotjs.sendMessage(msg.to,"I no there baby")
#========================
                        elif ("/ti/g/" in msg.text):
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                    n_links.append(l)
                            for ticket_id in n_links:
                                group = pkbotjs.findGroupByTicket(ticket_id)
                                pkbotjs.acceptGroupInvitationByTicket(group.id,ticket_id)
                                  
                        elif cmd == "sp" or cmd == "speed":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_group_time_start = time.time()
                                get_group = pkbotjs.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                pkbotjs.sendMessage(msg.to, "%s sᴇᴄᴏɴᴅs" % (get_group_time))
                                
                        elif cmd == "myfriend":
                          if msg._from in admin:
                            contactlist = pkbotjs.getAllContactIds()
                            kontak = pkbotjs.getContacts(contactlist)
                            num=1
                            msgs= "   ▪ғʀɪᴇɴᴅʟɪsᴛ\n"
                            for ids in kontak:
                                msgs+= "\n%i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+= "\n\nᴛᴏᴛᴀʟ :「%i」ғʀɪᴇɴᴅ" % len(kontak)
                            pkbotjs.sendMessage(msg.to, msgs+"\n")
                            
                        elif cmd == "glist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = pkbotjs.getGroupIdsJoined()
                               for i in gid:
                                   G = pkbotjs.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.name+ "\n"
                               pkbotjs.sendMessage(msg.to, "[Glist hitungan dari no 2]\nMaaf di sengajain biar kalian teliti\n\n"+ma+"\nᴛᴏᴛᴀʟ :「"+str(len(gid))+"」ɢʀᴏᴜᴘ\n")
#====================================================
                        if cmd.startswith('qr no '):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                text = msg.text.split()
                                number = text[1]
                                if number.isdigit():
                                    groups = pkbotjs.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        if msg.toType == 2:
                                            groupid = groups[int(number)]
                                            group = pkbotjs.getGroup(groupid)
                                            if group.preventedJoinByTicket == True:
                                                group.preventedJoinByTicket = False
                                                pkbotjs.updateGroup(group)
                                            gurl = pkbotjs.reissueGroupTicket(groupid)
                                            pkbotjs.sendMessage(msg.to,"Silahkan Masuk Boskuh\n " + str(group.name))
                                            pkbotjs.sendMessage(msg.to,'http://pkbotjs.me/R/ti/g/'+gurl)

                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +pkbotjs.getContact(m_id).displayName + "\n"
                                pkbotjs.sendMessage(msg.to, "   [ʟɪsᴛʙᴏᴛ]\n\n"+ma+"\nᴛᴏᴛᴀʟ :「%s」ʙᴏᴛs\n" %(str(len(Bots))))
                                
                        elif cmd == "listadmin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +pkbotjs.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +pkbotjs.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +pkbotjs.getContact(m_id).displayName + "\n"
                                for m_id in Bots:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +pkbotjs.getContact(m_id).displayName + "\n"
                                pkbotjs.sendMessage(msg.to, "    [ʟɪsᴛᴀᴅᴍɪɴ]\n\n🔰ᴏᴡɴᴇʀ :\n"+md+"\n🔰ᴀᴅᴍɪɴ :\n"+ma+"\n🔰sᴛᴀғғ :\n"+mb+"\n🔰Bots :\n"+mc+"\nᴛᴏᴛᴀʟ :「%s」ᴀᴅᴍɪɴʟɪsᴛ\n" %(str(len(owner)+len(admin)+len(staff)+len(creator))))
                                
                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = pkbotjs.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   pkbotjs.updateGroup(X)
                                   pkbotjs.sendMessage(msg.to, "✓ᴏᴘᴇɴ ᴜʀʟ")

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = pkbotjs.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   pkbotjs.updateGroup(X)
                                   pkbotjs.sendMessage(msg.to, "✘ᴄʟᴏsᴇᴅ ᴜʀʟ")

                        elif cmd == "changePicture":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                pkbotjs.sendMessage(msg.to, "sᴇɴᴅ ᴘʜᴏᴛᴏ...")
                                
                        elif cmd == "upbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["Pkfoto"][mid] = True
                                pkbotjs.sendMessage(msg.to, "sᴇɴᴅ  ᴘʜᴏᴛᴏ...")
                                
                        elif cmd.startswith("name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = pkbotjs.getProfile()
                                profile.displayName = string
                                pkbotjs.updateProfile(profile)
                                pkbotjs.sendMessage(msg.to, "✓sᴜᴄᴄᴇss " + string + "")
                                
                        elif cmd == 'pepek' or cmd == 'taik':
                          if msg._from in admin:
                            members = []
                            if msg.toType == 1:
                                room = pkbotjs.getCompactRoom(to)
                                members = [mem.mid for mem in room.contacts]
                            elif msg.toType == 2:
                                group = pkbotjs.getCompactGroup(to)
                                members = [mem.mid for mem in group.members]
                            else:
                                return pkbotjs.sendMessage(msg.to, '✘ғᴀɪʟᴇᴅ ᴍᴇɴᴛɪᴏɴ ᴀʟʟ ᴍᴇᴍʙᴇʀs')
                            if members:
                                famzmention(to, members)

                        if ("Kick " in msg.text):
                            if msg._from in admin:
                                start = time.time()
                                time.sleep(0.00001)
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target not in Team:
                                        try:
                                            wait["blacklist"][target] = True
                                            wait["protectjoin"] = True
                                            wait["protectinvite"] = True
                                            wait["protectqr"] = True
                                            pkbotjs.kickoutFromGroup(msg.to, [target])
                                        except:
                                            pass

                        elif "Lkick " in msg.text:
                          if msg._from in admin:
                             start = time.time()
                             time.sleep(0.00001)
                             nk0 = msg.text.replace("Lkick ","")
                             nk1 = nk0.lstrip()
                             nk2 = nk1.replace("@","")
                             nk3 = nk2.rstrip()
                             _name = nk3
                             gs = pkbotjs.getGroup(msg.to)
                             targets = []
                             cms = 'kick.js gid={} token={} app={}'.format(to,token,appF)
                             for s in gs.members:
                                 if _name in s.displayName:
                                    targets.append(s.mid)
                             if targets == []:
                                 pkbotjs.sendMessage(msg.to, "✘ᴜsᴇʀ ᴅᴏᴇs ɴᴏᴛ ᴇxɪsᴛ")
                                 pass
                             else:
                                 for target in targets:
                                    if target not in Team:
                                      try:
                                          cms += ' uid={}'.format(target)
                                          success = execute_js(cms)
                                          if success:
                                              pkbotjs.sendMessage(msg.to,'Execute success')
                                          else:
                                              pkbotjs.sendMessage(msg.to,'limit')
                                      except:
                                          pass

                        elif ("Addfriend " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           pkbotjs.findAndAddContactsByMid(target)
                                           pkbotjs.sendMessage(msg.to,"Berhasil menambahkan teman")
                                       except:
                                           pass

                        elif ("Sbadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           pkbotjs.findAndAddContactsByMid(target)
                                           pkbotjs.sendMessage(msg.to,"Berhasil menambahkan teman")
                                       except:
                                           pass
                                          
                        elif ("Addadmin " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in creator:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target not in admin:
                                        admin.append(target)
                                        pkbotjs.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴀᴅᴅ ᴀᴅᴍɪɴ")
                                    else:
                                        pkbotjs.sendMessage(msg.to, "sudah menjadi anggota ᴀᴅᴍɪɴ")

                        elif ("Addstaff " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target not in staff:
                                        staff.append(target)
                                        pkbotjs.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴀᴅᴅ staff")
                                    else:
                                        pkbotjs.sendMessage(msg.to, "sudah menjadi anggota staff")

                        elif ("Addbots " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target not in Bots:
                                        Bots.append(target)
                                        pkbotjs.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴀᴅᴅ Bots")
                                    else:
                                        pkbotjs.sendMessage(msg.to, "sudah menjadi anggota Bots")

                        elif ("Delladmin " in msg.text):
                            if msg._from in creator:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           admin.remove(target)
                                           pkbotjs.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ ᴀᴅᴍɪɴ")
                                       except:
                                           pass

                        elif ("Dellstaff " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           staff.remove(target)
                                           pkbotjs.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ sᴛᴀғғ")
                                       except:
                                           pass

                        elif ("Dellbots " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           Bots.remove(target)
                                           pkbotjs.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ ʙᴏᴛs")
                                       except:
                                           pass

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["protectjoin"] = False
                              wait["protectinvite"] = False
                              wait["protectqr"] = False
                              if wait["blacklist"] == {}:
                                pkbotjs.sendMessage(msg.to,"Tidak ada Anak anjing")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +pkbotjs.getContact(m_id).displayName + "\n"
                                pkbotjs.sendMessage(msg.to,"Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))
                                       
                        elif cmd == "clearban" or text.lower() == 'cban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ragets = pkbotjs.getContacts(wait["blacklist"])
                              mc = "「%i」" % len(ragets)
                              pkbotjs.sendMessage(msg.to, mc+": Anak Anjing Dibebaskan")
                              wait["blacklist"] = {}
                              wait["protectjoin"] = False
                              wait["protectinvite"] = False
                              wait["protectqr"] = False

                        elif 'Set response: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set response: ','')
                              if spl in [""," ","\n",None]:
                                  pkbotjs.sendMessage(msg.to, "✘ғᴀɪʟᴇᴅ ᴛᴏ ʀᴇᴘʟᴀᴄᴇ ʀᴇsᴘᴏɴsᴇ")
                              else:
                                  wait["Response"] = spl
                                  pkbotjs.sendMessage(msg.to, "✓ᴍsɢ ʀᴇsᴘᴏɴsᴇ ᴄʜᴀɴɢᴇᴅ\n「{}」".format(str(spl)))

    except Exception as error:
        print (error)
while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                oepoll.setRevision(op.revision)
                thread = threading.Thread(target=bot, args=(op,))
                thread.start()
    except Exception as e:
        print(e)
